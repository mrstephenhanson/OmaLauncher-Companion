# OmaCompanion — Android Companion & Arch Linux Bridge

A Tokyo Night Jetpack Compose companion app for OmaLauncher and Arch Linux.

## Features
- **Control Deck**: Real-time status, battery telemetry, and quick bridge actions.
- **AUR Package Browser**: Live search and 1-click install queuing into Arch Linux (`yay` / `pacman`).
- **Remote Arch Command Runner**: Execute bash commands on your Arch Linux computer from your phone and stream back stdout.
- **2-Way Clipboard Sync**: Direct integration with Android `ClipboardManager` and Arch Linux `oma-cli clip get/set`.
- **Background Bridge Server**: Runs an HTTP daemon on port 8765 with foreground notification support.

---

## Quick Start: Install to your Android Phone

### Option A: Using Android Studio (Recommended)
1. Unzip `OmaCompanion.zip`.
2. Open Android Studio -> **File > Open** -> select the `OmaCompanion` folder.
3. Enable **Developer Options** and **USB Debugging** on your Android phone.
4. Plug your phone into your computer via USB.
5. Click the green **Run (Shift + F10)** button in Android Studio.
6. The app will build and install directly onto your phone!

### Option B: Command Line (Gradle & ADB)
```bash
cd OmaCompanion
# Build debug APK
./gradlew assembleDebug

# Install to connected phone
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Arch Linux Setup
On your Arch Linux machine:

1. Install `oma-cli`:
```bash
sudo cp arch-host/oma-cli /usr/local/bin/oma-cli
sudo chmod +x /usr/local/bin/oma-cli
```

2. Connect to the phone bridge:
- **If connected via USB**:
  ```bash
  adb reverse tcp:8765 tcp:8765
  ```
- **If connected over Wi-Fi LAN**:
  ```bash
  export OMA_BRIDGE_URL="http://<phone-ip-address>:8765"
  ```

3. Run the background worker daemon:
```bash
oma-cli worker
```

4. Test commands:
```bash
oma-cli battery
oma-cli clip get
oma-cli clip set "Hello from Arch Linux!"
oma-cli notify "Test" "Bridge works!"
```
